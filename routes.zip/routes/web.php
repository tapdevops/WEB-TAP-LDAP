<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
	return response()->json([
		"message" => "Microservice LDAP"
	]);
});

Route::post( '/login', 'AuthController@login' );
Route::get( '/export', 'ExportController@index' );
Route::get( '/export/tm-block', 'ExportController@sync_tm_block' );
Route::get( '/export/tm-est', 'ExportController@sync_tm_est' );
Route::get( '/export/tm-region', 'ExportController@sync_tm_region' );
Route::get( '/export/tm-comp', 'ExportController@sync_tm_comp' );
Route::get( '/export/tm-afd', 'ExportController@sync_tm_afd' );
Route::get( '/export/tm-employee-hris', 'ExportController@sync_tm_employee_hris' );