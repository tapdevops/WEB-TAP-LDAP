<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Collection;
use Session;
use Config;
use URL;
use Validator;
use App\LDAP;

class AuthController extends Controller {
	
	public function __construct() {
		// ..
	}

	public function login( Request $request ) {

		$response['status'] = false;
		$response['message'] = 'Validasi Gagal';

		$validator = Validator::make( $request->all(), [
			'username' => 'required|regex:/(^([a-zA-Z.]+)(\d+)?$)/u|max:64',
			'password' => 'required|max:64|'
		] );

		if ( $validator->fails() ) {
			$response['message'] = 'Validasi Gagal';
		}
		else {
			$LDAP = new LDAP();
			$LDAP_check = LDAP::auth( $request->username, $request->password );
			$response = $LDAP_check;
		}

		return response()->json( $LDAP_check );

	}

}