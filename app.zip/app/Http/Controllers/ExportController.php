<?php
namespace App\Http\Controllers;
set_time_limit(0);
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Collection;
use Session;
use Config;
use View;
use URL;

class ExportController extends Controller {
	
	protected $url;

	public function __construct() {
		$this->tap_dw = DB::connection( 'tap_dw' );
		$this->url = array(
			'tm_est' => 'http://149.129.242.205:3003/sync/est',
			'tm_block' => 'http://149.129.242.205:3003/sync/block',
			'tm_region' => 'http://149.129.242.205:3003/sync/region',
			'tm_comp' => 'http://149.129.242.205:3003/sync/comp',
			'tm_afd' => 'http://149.129.242.205:3003/sync/afd',
			'tm_employee_hris' => 'http://149.129.242.205:3001/sync/employee-hris',

			'sync_db_log' => 'http://149.129.242.205:3001/api/sync-db-log',
		);
	}

	public function index() {
		/* GET Guzzle Sample
		
			$res = $client->request('GET', 'http://149.129.242.205:3002/api/afdeling');
			echo $res->getStatusCode();
			echo $res->getHeaderLine('content-type');
			echo $res->getBody();
			$res = $client->request('POST', 'http://149.129.242.205:3002/api/afdeling', [
				'form_params' => [
					'REGION_CODE' => '04',
					'COMP_CODE' => '42',
					'EST_CODE' => '31',
					'WERKS' => '4121',
					'AFD_CODE' => 'A',
					'BLOCK_CODE' => '001',
					'BLOCK_NAME' => 'AA12',
				]
			]);
			
			echo $res->getStatusCode();
			echo $res->getHeader('content-type');
			echo print_r($res->getBody());
		*/
	}

	public function sync_tm_afd() {
		$sql = "SELECT * FROM TM_AFD";
		$query = $this->tap_dw->select( $sql );
		$client = new \GuzzleHttp\Client();
		$start_time = date( 'Y-m-d H:i:s' );

		print( 'SYNC: <b>AFDELING</b><br />' );
		print( '---------------------------------------<br />' );

		if ( count( $query ) > 0 ) {
			foreach ( $query as $data ) {
				
				$res = $client->request('POST', 'http://149.129.242.205:3003/sync/afdeling', [
					'form_params' => [
						'REGION_CODE' => $data->region_code,
						'COMP_CODE' => $data->comp_code,
						'EST_CODE' => $data->est_code,
						'WERKS' => $data->werks,
						'AFD_CODE' => $data->afd_code,
						'AFD_NAME' => ( $data->afd_name != '' ) ? $data->afd_name : '',
						'WERKS_AFD_CODE' => $data->afd_code_gis,
						'START_VALID' => ( $data->start_valid != '' ) ? $data->start_valid : '',
						'END_VALID' => ( $data->end_valid != '' ) ? $data->end_valid : '',
						'UPDATE_TIME_DW' => ( $data->update_time_dw != '' ) ? $data->update_time_dw : '',
						'INSERT_TIME_DW' => ( $data->insert_time_dw != '' ) ? $data->insert_time_dw : '',
						'INSERT_USER' => '',
						'INSERT_TIME' => '',
						'UPDATE_USER' => '',
						'UPDATE_TIME' => ''
					]
				]);

				print '-> '.$data->afd_code_gis.' Done<br />';
			}

			$end_time = date( 'Y-m-d H:i:s' );
			$res = $client->request('POST', $this->url['sync_db_log'], [
				'form_params' => [
					'TABLE_NAME' => 'TM_COMP',
					'NUMROWS' => count( $query ),
					'START_TIME' => $start_time,
					'END_TIME' => $end_time
				]
			]);
		}

	}

	public function sync_tm_est() {
		$sql = "SELECT * FROM TM_EST";
		$query = $this->tap_dw->select( $sql );
		$client = new \GuzzleHttp\Client();
		$start_time = date( 'Y-m-d H:i:s' );

		print( 'SYNC: <b>EST</b><br />' );
		print( '---------------------------------------<br />' );

		if ( count( $query ) > 0 ) {
			foreach ( $query as $data ) {
				$res = $client->request('POST', $this->url['tm_est'], [
					'form_params' => [
						'NATIONAL' => $data->national,
						'REGION_CODE' => $data->region_code,
						'COMP_CODE' => $data->comp_code,
						'EST_CODE' => $data->est_code,
						'WERKS' => $data->werks,
						'EST_NAME' => $data->est_name,
						'START_VALID' => $data->start_valid,
						'END_VALID' => $data->end_valid,
						'CITY' => $data->city,
						'INSERT_TIME_DW' => $data->insert_time_dw,
						'UPDATE_TIME_DW' => $data->update_time_dw,
					]
				]);

				print '-> '.$data->werks.' Done<br />';
			}

			$end_time = date( 'Y-m-d H:i:s' );
			$res = $client->request('POST', $this->url['sync_db_log'], [
				'form_params' => [
					'TABLE_NAME' => 'TM_EST',
					'NUMROWS' => count( $query ),
					'START_TIME' => $start_time,
					'END_TIME' => $end_time
				]
			]);
		}
	}

	public function sync_tm_region() {
		$sql = "SELECT * FROM TM_REGION";
		$query = $this->tap_dw->select( $sql );
		$client = new \GuzzleHttp\Client();
		$start_time = date( 'Y-m-d H:i:s' );

		print( 'SYNC: <b>REGION</b><br />' );
		print( '---------------------------------------<br />' );

		if ( count( $query ) > 0 ) {
			foreach ( $query as $data ) {
				
				$res = $client->request('POST', $this->url['tm_region'], [
					'form_params' => [
						'NATIONAL' => $data->national,
						'REGION_CODE' => $data->region_code,
						'REGION_NAME' => $data->region_name,
						'INSERT_TIME_DW' => $data->insert_time_dw,
						'UPDATE_TIME_DW' => ( $data->update_time_dw != null ) ? $data->update_time_dw : ''
					]
				]);

				print '-> '.$data->region_code.' Done<br />';

			}

			$end_time = date( 'Y-m-d H:i:s' );
			$res = $client->request('POST', $this->url['sync_db_log'], [
				'form_params' => [
					'TABLE_NAME' => 'TM_REGION',
					'NUMROWS' => count( $query ),
					'START_TIME' => $start_time,
					'END_TIME' => $end_time
				]
			]);
		}
	}

	public function sync_tm_employee_hris() {
		$sql = "SELECT * FROM TM_EMPLOYEE_HRIS WHERE ROWNUM < 20";
		$query = $this->tap_dw->select( $sql );
		$client = new \GuzzleHttp\Client();
		$start_time = date( 'Y-m-d H:i:s' );

		print( 'SYNC: <b>EMPLOYEE HRIS</b><br />' );
		print( '---------------------------------------<br />' );

		if ( count( $query ) > 0 ) {
			foreach ( $query as $data ) {
				$res = $client->request('POST', $this->url['tm_employee_hris'], [
					'form_params' => [
						'EMPLOYEE_NIK' => $data->employee_nik,
						'EMPLOYEE_USERNAME' => $data->employee_username,
						'EMPLOYEE_FULLNAME' => $data->employee_fullname,
						'EMPLOYEE_GENDER' => $data->employee_gender,
						'EMPLOYEE_RELIGION' => $data->employee_religion,
						'EMPLOYEE_BIRTHDAY' => $data->employee_birthday,
						'EMPLOYEE_BANKCODE' => $data->employee_bankcode,
						'EMPLOYEE_BANKNAME' => $data->employee_bankname,
						'EMPLOYEE_BANKACCOUNT' => $data->employee_bankaccount,
						'EMPLOYEE_ACCBANKNAME' => $data->employee_accbankname,
						'EMPLOYEE_POSITIONCODE' => $data->employee_positioncode,
						'EMPLOYEE_POSITION' => $data->employee_position,
						'EMPLOYEE_GRADECODE' => $data->employee_gradecode,
						'EMPLOYEE_GRADE' => $data->employee_grade,
						'EMPLOYEE_LEVEL' => $data->employee_level,
						'EMPLOYEE_DEPTCODE' => $data->employee_deptcode,
						'EMPLOYEE_DEPARTMENT' => $data->employee_department,
						'EMPLOYEE_DIVCODE' => $data->employee_divcode,


						'EMPLOYEE_DIVISION' => $data->employee_division,
						'EMPLOYEE_COMPANYCODE' => $data->employee_companycode,
						'EMPLOYEE_LOCATIONCODE' => $data->employee_locationcode,
						'EMPLOYEE_LOCATION' => $data->employee_location,
						'EMPLOYEE_EMAIL' => $data->employee_email,
						'EMPLOYEE_SPVNIK' => $data->employee_spvnik,
						'EMPLOYEE_SPV' => $data->employee_spv,


						'EMPLOYEE_JOINDATE' => $data->employee_joindate,
						'EMPLOYEE_RESIGNDATE' => $data->employee_resigndate,


						'INSERT_TIME_DW' => $data->insert_time_dw,
						'UPDATE_TIME_DW' => $data->update_time_dw,
						'DELETE_TIME_DW' => $data->delete_time_dw,


						'EMPLOYEE_POSITIONCODE_HCIS' => $data->employee_positioncode_hcis,
						'EMPLOYEE_DEPTCODE_HCIS' => $data->employee_deptcode_hcis,
						'EMPLOYEE_DIVCODE_HCIS' => $data->employee_divcode_hcis,
						'EMPLOYEE_LOCATIONCODE_HCIS' => $data->employee_locationcode_hcis


					]
				]);

				print '-> '.$data->employee_nik.' Done<br />';

			}

			$end_time = date( 'Y-m-d H:i:s' );
			$res = $client->request('POST', $this->url['sync_db_log'], [
				'form_params' => [
					'TABLE_NAME' => 'TM_EMPLOYEE_HRIS',
					'NUMROWS' => count( $query ),
					'START_TIME' => $start_time,
					'END_TIME' => $end_time
				]
			]);
		}
	}

	public function sync_tm_comp() {
		$sql = "SELECT * FROM TM_COMP";
		$query = $this->tap_dw->select( $sql );
		$client = new \GuzzleHttp\Client();
		$start_time = date( 'Y-m-d H:i:s' );

		print( 'SYNC: <b>COMP</b><br />' );
		print( '---------------------------------------<br />' );

		if ( count( $query ) > 0 ) {
			foreach ( $query as $data ) {
				
				$res = $client->request('POST', $this->url['tm_comp'], [
					'form_params' => [
						'NATIONAL' => $data->national,
						'REGION_CODE' => $data->region_code,
						'COMP_CODE' => $data->comp_code,
						'COMP_NAME' => $data->comp_name,
						'ADDRESS' => $data->address,
						'INSERT_TIME_DW' => ( $data->insert_time_dw != null ) ? $data->insert_time_dw : '',
						'UPDATE_TIME_DW' => ( $data->update_time_dw != null ) ? $data->update_time_dw : ''
					]
				]);

				print '-> '.$data->comp_code.' Done<br />';

			}

			$end_time = date( 'Y-m-d H:i:s' );
			$res = $client->request('POST', $this->url['sync_db_log'], [
				'form_params' => [
					'TABLE_NAME' => 'TM_COMP',
					'NUMROWS' => count( $query ),
					'START_TIME' => $start_time,
					'END_TIME' => $end_time
				]
			]);
		}
	}

	public function sync_tm_block() {

		$sql = "SELECT
				BLOCK.REGION_CODE,
				BLOCK.COMP_CODE,
				BLOCK.EST_CODE,
				BLOCK.WERKS,
				BLOCK.AFD_CODE,
				BLOCK.BLOCK_CODE,
				BLOCK.BLOCK_NAME,
				BLOCK.BLOCK_CODE_GIS,
				BLOCK.START_VALID,
				BLOCK.END_VALID
			FROM 
				TM_BLOCK BLOCK
			WHERE
				ROWNUM < 20
			GROUP BY
				REGION_CODE,
				COMP_CODE,
				EST_CODE,
				WERKS,
				AFD_CODE,
				BLOCK_CODE,
				BLOCK_NAME,
				BLOCK_CODE_GIS,
				START_VALID,
				END_VALID";
		$query = $this->tap_dw->select( $sql );
		$client = new \GuzzleHttp\Client();
		$start_time = date( 'Y-m-d H:i:s' );

		print( 'SYNC: <b>BLOCK</b><br />' );
		print( '---------------------------------------<br />' );

		if ( count( $query ) > 0 ) {
			foreach ( $query as $data ) {
				
				$res = $client->request('POST', $this->url['tm_block'], [
					'form_params' => [
						'REGION_CODE' => $data->region_code,
						'COMP_CODE' => $data->comp_code,
						'EST_CODE' => $data->est_code,
						'WERKS' => $data->werks, 
						'AFD_CODE' => $data->afd_code,
						'BLOCK_CODE' => $data->block_code,
						'BLOCK_NAME' => $data->block_name,
						'WERKS_AFD_BLOCK_CODE' => $data->block_code_gis,
						'LATITUDE_BLOCK' => '',
						'LONGITUDE_BLOCK' => '',
						'START_VALID' => ( $data->start_valid != null ) ? $data->start_valid : '',
						'END_VALID' => ( $data->end_valid != null ) ? $data->end_valid : '',
						'INSERT_USER' => '',
						'INSERT_TIME' => '',
						'UPDATE_USER' => '',
						'UPDATE_TIME' => ''
					]
				]);

				print '-> '.$data->block_code_gis.' Done<br />';
			}

			
			$end_time = date( 'Y-m-d H:i:s' );
			$res = $client->request('POST', $this->url['sync_db_log'], [
				'form_params' => [
					'TABLE_NAME' => 'TM_BLOCK',
					'NUMROWS' => count( $query ),
					'START_TIME' => $start_time,
					'END_TIME' => $end_time
				]
			]);
		}
	}

}


